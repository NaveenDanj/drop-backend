<?php

namespace App\Http\Controllers;

use App\Models\UserFile;
use Illuminate\Http\Request;

class FileDownloadController extends Controller
{

    public function downloadFile(Request $request , $linkid){
    	// $myFile = storage_path("app/public/remember the name_1632552046.mp4");

        $requested_file = UserFile::where('fileID' , $linkid)->first();

        $myFile =  storage_path('app/files/'.$requested_file->name);

        return response()->download($myFile);



        // if ($requested_file === null) {
        //     return redirect('/filenotfound');
        // }else{

        //     if( round(microtime(true) * 1000) > $requested_file->expire_at ){
        //         return redirect('/filenotfound');
        //     }

        //     if( (int)$requested_file->expire_after <= $requested_file->downloads  ){
        //         return redirect('/filenotfound');
        //     }

        //     if( $requested_file->password !== null){

        //         return redirect("/password-protected/".$linkid);

        //     }else{

        //         $requested_file->downloads = $requested_file->downloads + 1;
        //         $requested_file->save();
        //         $myFile =  storage_path('app/'.$requested_file->location);

        //         return response()->download($myFile);
        //     }

        // }

    }

    public function checkFileExists(Request $request , $linkid){

        $requested_file = UserFile::where('fileID' , $linkid)->first();

        if ($requested_file === null) {

            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'File not found'
                ] , 404
            );

        }else{

            // check if download limit is reached
            // if($requested_file->isDownloadExpired){

            //     if( $requested_file->download_count <= $requested_file->download_expired_at ){

            //         return response()->json(
            //             [
            //                 'status' => 'error',
            //                 'message' => 'Download limit reached'
            //             ] , 404
            //         );

            //     }

            // }

            $requested_file = UserFile::where('fileID' , $linkid)->first();

            return response()->json(
                [
                    'status' => 'success',
                    'message' => 'File found',
                    'file' => $requested_file
                ] , 200
            );

        }


    }


}
